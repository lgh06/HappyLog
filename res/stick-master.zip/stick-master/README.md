Stick
=======
#stick是什么
stick是一个响应式的瀑布流组件。

#DEMO
……

#如何使用
……
